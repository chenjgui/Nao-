global IP
global port

IP = "192.168.1.105"
port = 9559
