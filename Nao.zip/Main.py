import sys
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
from PyQt4.QtCore import Qt

from Model.VideoModel import VideoModel
from Model.EmotionModel import EmotionModel
from Model.SayModel import SayModel
from Model.WalkModel import WalkModel
from Model.TurnAroundModel import TurnAroundModel
from Model.RedBallModel import RedBallModel
from Model.DrawModel import DrawModel
from Model.ArmModel import ArmModel
from Model.PutDownArmModel import PutDownArmModel
from Model.OpenHandModel import OpenHandModel
from Model.CloseHandModel import CloseHandModel

import Setting
from View import MainView

import time
import vision_definitions
# Python Image Library
import PIL.Image

from naoqi import ALProxy
from naoqi import ALBroker
from naoqi import ALModule
import argparse
import motion
import almath
#IP = "192.168.1.118"




class MainAPP(QtGui.QMainWindow, MainView.Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainAPP, self).__init__(parent)
        self.setupUi(self)
        self.vidModel = VideoModel(Setting.IP, Setting.port)
        self.emotionModel = EmotionModel(Setting.IP, Setting.port)
        self.sayModel = SayModel(Setting.IP, Setting.port)
        self.walkModel = WalkModel(Setting.IP, Setting.port)
        self.turnaroundModel = TurnAroundModel(Setting.IP, Setting.port)
        self.redballModel = RedBallModel(Setting.IP, Setting.port)
        self.drawModel = DrawModel(Setting.IP, Setting.port)
        self.armModel = ArmModel(Setting.IP, Setting.port)
        self.putdownarmModel = PutDownArmModel(Setting.IP, Setting.port)
        self.openhandModel = OpenHandModel(Setting.IP, Setting.port)
        self.closehandModel = CloseHandModel(Setting.IP, Setting.port)

        self.angryProb.connect(self.emotionModel, SIGNAL('emotionProb'), self.setEmotionProb, Qt.AutoConnection)
        self.videoPanel.connect(self.vidModel, SIGNAL('newImage(QImage)'), self.setFrame, Qt.AutoConnection)
        self.vidModel.start()
        self.emotionModel.start()

    # set the value of video panel with image
    def setFrame(self, frame):
        # 该属性包含标签的像素图。
        self.videoPanel.setPixmap(QtGui.QPixmap.fromImage(frame))

    #set emotion prob
    def setEmotionProb(self, prob):
        try:
            self.angryProb.setValue(prob[3])
            self.happyProb.setValue(prob[1])
            self.neutralProb.setValue(prob[0])
            self.sadProb.setValue(prob[4])
            self.surprisedProb.setValue(prob[2])
        except Exception:
            self.angryProb.setValue(0)
            self.happyProb.setValue(0)
            self.neutralProb.setValue(0)
            self.sadProb.setValue(0)
            self.surprisedProb.setValue(0)

    def say(self):
        self.sayModel.run()
        

    def walk(self):
        self.walkModel.run()


    def trunaround(self):
        self.turnaroundModel.run()


    def redball(self):
        self.redballModel.run()


    def draw(self):
        self.drawModel.run()


    def putdownarm(self):
        self.putdownarmModel.run()


    def arm(self):
        self.armModel.run()


    def openhand(self):
        self.openhandModel.run()


    def closehand(self):
        self.closehandModel.run()
        

def main(self):
    app = QtGui.QApplication(sys.argv)
    #create new instance of MainAPP()
    mainWindow = MainAPP()
    #show the window
    mainWindow.show()
    #execute the app
    app.exec_()


if __name__ == "__main__":
    main(self=None)
