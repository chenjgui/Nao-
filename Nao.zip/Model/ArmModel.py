import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import almath
import time


shoulder_pitch_max = -30
RShoulderPitchName = "RShoulderPitch"


class ArmModel(QThread):
    def __init__(self, IP, port):
        super(ArmModel, self).__init__()
        self.IP = IP
        self.port = port


    def run(self):
        # nao_lift_arm
        motion_proxy = ALProxy("ALMotion", self.IP, self.port)
        motion_proxy.wakeUp()
        hand_speed = 0.2
        #turn to hudu
        motion_proxy.setAngles(RShoulderPitchName, shoulder_pitch_max * almath.TO_RAD, hand_speed) 