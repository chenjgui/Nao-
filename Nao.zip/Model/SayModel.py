import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL


class SayModel(QThread):
    def __init__(self, IP, port):
        super(SayModel, self).__init__()
        self.IP = IP
        self.port = port

    def run(self):
        #create instance of ALTextToSpeech 
        tts = ALProxy("ALTextToSpeech", self.IP, self.port)
        tts.say("Hello, my friends!")
        