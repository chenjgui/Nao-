import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import almath
import time


#shoulder_pitch_max = -30
#headYawName = "HeadYaw"
#headPitchName = "HeadPitch"
#RShoulderRollName = "RShoulderRoll"
#RShoulderPitchName = "RShoulderPitch"
#RElbowRollName = "RElbowRoll"
#RElbowYawName = "RElbowYaw"
#RWristYawName = "RWristYaw"
RHandName = "RHand"


class OpenHandModel(QThread):
    def __init__(self, IP, port):
        super(OpenHandModel, self).__init__()
        self.IP = IP
        self.port = port


    def run(self):
        # nao_open_hand
        speed = 0.2
        motion_proxy = ALProxy("ALMotion", self.IP, self.port)
        motion_proxy.wakeUp()
        motion_proxy.setAngles(RHandName, 1.0, speed)  # non-blocking call
        #motion_proxy.rest() 
        