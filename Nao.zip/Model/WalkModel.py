import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL


class WalkModel(QThread):
    def __init__(self, IP, port):
        super(WalkModel, self).__init__()
        self.IP = IP
        self.port = port

    def run(self):
        motionProxy = ALProxy("ALMotion", self.IP, self.port)
        postureProxy = ALProxy("ALRobotPosture", self.IP, self.port)
        motionProxy.wakeUp()
        postureProxy.goToPosture("StandInit", 0.5)
        motionProxy.moveTo(0.2, 0, 0)
        motionProxy.setMoveArmsEnabled(True, True)
        motionProxy.setMotionConfig([["ENABLE_FOOT_CONTACT_PROTECTION", True]])
        motionProxy.rest()
