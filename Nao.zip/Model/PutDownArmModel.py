import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import almath
import time


RShoulderRollName = "RShoulderRoll"
RShoulderPitchName = "RShoulderPitch"
RElbowYawName = "RElbowYaw"
RWristYawName = "RWristYaw"


class PutDownArmModel(QThread):
    def __init__(self, IP, port):
        super(PutDownArmModel, self).__init__()
        self.IP = IP
        self.port = port


    def run(self):
        # nao_lift_armdef nao_unmove_arm(ip, port):
        motion_proxy = ALProxy("ALMotion", self.IP, self.port)
        motion_proxy.wakeUp()
        speed = 0.2
        motion_proxy.setAngles(RShoulderRollName, -80 * almath.TO_RAD, speed)
        time.sleep(1)
        motion_proxy.setAngles(RShoulderPitchName, 100 * almath.TO_RAD, speed)
        time.sleep(1)
        motion_proxy.setAngles(RShoulderRollName, -16 * almath.TO_RAD, speed)
        time.sleep(1)
        motion_proxy.setAngles(RElbowYawName, 115.0 * almath.TO_RAD, speed)
        motion_proxy.setAngles(RWristYawName, -28.0 * almath.TO_RAD, 0.5)
        motion_proxy.rest()