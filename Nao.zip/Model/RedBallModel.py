import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import time


class RedBallModel(QThread):
    def __init__(self, IP, port):
        super(RedBallModel, self).__init__()
        self.IP = IP
        self.port = port

    def run(self):
        motion = ALProxy("ALMotion", self.IP, self.port)
        posture = ALProxy("ALRobotPosture", self.IP, self.port)
        tracker = ALProxy("ALTracker", self.IP, self.port)
        tts = ALProxy("ALTextToSpeech", self.IP, self.port)
    # First, wake up.
        motion.wakeUp()
        #tts.say("are you see the red ball?")
        time.sleep(0.5)
        fractionMaxSpeed = 0.8
    # Go to posture stand
        posture.goToPosture("StandInit", fractionMaxSpeed)
    # Add target to track.
        targetName = "RedBall"
        diameterOfBall = 0.06
        tracker.registerTarget(targetName, diameterOfBall)
    # set mode
    #mode = "Move"
        tts.say("are you see the red ball?")
        mode = "Head"
        tracker.setMode(mode)
    # Then, start track red ball.
        tracker.track(targetName)
        time.sleep(3)
        #tts.say("please give me the red ball.")
    # Stop tracker, go to posture Sit.
        tracker.stopTracker()
        tracker.unregisterAllTargets()
    #posture.goToPosture("Sit", fractionMaxSpeed)
    # Add target to track.
        targetName = "Face"
        faceWidth = 0.1
        tracker.registerTarget(targetName, faceWidth)
    # Then, start tracker.
        tracker.track(targetName)
        time.sleep(2)

        tts.say("please give me the red ball.")
        
    # Stop tracker.
        tracker.stopTracker()
        tracker.unregisterAllTargets()
        #motion.rest()