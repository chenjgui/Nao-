import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import almath
import time


RHandName = "RHand"


class CloseHandModel(QThread):
    def __init__(self, IP, port):
        super(CloseHandModel, self).__init__()
        self.IP = IP
        self.port = port


    def run(self):
        # nao_close_hand
        motion_proxy = ALProxy("ALMotion", self.IP, self.port)
        tts = ALProxy("ALTextToSpeech", self.IP, self.port)
        motion_proxy.wakeUp()
        speed=0.5
        motion_proxy.setAngles(RHandName, 0.0, speed)  # non-blocking call
        tts.say("thank you!")