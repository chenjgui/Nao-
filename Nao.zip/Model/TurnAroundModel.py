import sys
from naoqi import ALProxy
from PyQt4.QtCore import QThread
from PyQt4 import QtGui
from PyQt4.QtCore import SIGNAL
import time


class TurnAroundModel(QThread):
    def __init__(self, IP, port):
        super(TurnAroundModel, self).__init__()
        self.IP = IP
        self.port = port

    def run(self):
        motionProxy = ALProxy("ALMotion", self.IP, self.port)
        postureProxy = ALProxy("ALRobotPosture", self.IP, self.port)

    # Set NAO in Stiffness On
        StiffnessOn(motionProxy)
    # Send NAO to Pose Init
        postureProxy.goToPosture("StandInit", 0.5)

    #TARGET VELOCITY
        x     = 0.2
        y     = -0.3
        theta = 0.8
        frequency = 0.5
        motionProxy.moveToward(x, y, theta, [["Frequency", frequency]])
        time.sleep(8.0)
        motionProxy.rest() 

def StiffnessOn(proxy):
    # We use the "Body" name to signify the collection of all joints
    pNames = "Body"
    pStiffnessLists = 1.0
    pTimeLists = 1.0
    proxy.stiffnessInterpolation(pNames, pStiffnessLists, pTimeLists)